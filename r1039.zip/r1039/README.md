# R1039

A browser extension that looks up Japanese text the moment you copy it —
by selecting it on a page, or via an external OCR tool that writes
straight to the system clipboard — and shows word-by-word definitions
in a small panel, plus a combined-phrase definition when the whole
copied string is itself a dictionary entry. Data source: the public
[Jisho.org](https://jisho.org) API.

## Install

1. Open `chrome://extensions` (or `opera://extensions` in Opera)
2. Enable **Developer mode**
3. **Load unpacked** → select this folder
4. Click the toolbar icon once to confirm it shows **ON** (click again to disable)

## Features

- Light theme by default; the small circle bottom-right toggles dark
  mode (persisted).
- Drag the top bar to move the panel; it reopens at that position next
  time. First open is centered in the viewport.
- Only the **×** closes it — clicking elsewhere on the page doesn't,
  so it won't interrupt a drag.
- Copying new text while a panel is open replaces it automatically.
- Each word: reading above, kanji/kana headword, romanized reading, a
  copy icon, a pronunciation (TTS) icon, JLPT/part-of-speech/common
  tags, and numbered definitions.
- Definitions stream in as they're found, rather than waiting for the
  whole phrase before showing anything.
- Five scrollbar color themes, each with a matching particle effect.

## How it works

- `content/content.js` listens for the browser's native `copy` event
  (instant, but only catches real on-page selections).
- `offscreen.js` (an offscreen document, spun up by `background.js`)
  polls the OS clipboard every 700ms via `document.execCommand('paste')`,
  so it also catches text placed there by an external OCR tool, another
  app, or a site that blocks normal text selection.
- Both paths message `background.js`, which does the Jisho lookups
  (service workers aren't bound by the host page's CSP) and streams
  results back token-by-token as `lib/segmenter.js` resolves them.
- `lib/segmenter.js` splits the copied string into words via greedy
  longest-match against live Jisho lookups.
- `lib/romaji.js` renders a romanized reading locally, with no extra
  network call.
- `content/render.js` builds and positions the panel.
- `content/effects.js` drives the scrollbar-themed visual effects (see
  `popup.css` for the color/gradient values): an inner glow along the
  scrollbar gutter that pulses on scroll for every theme, plus an outer
  particle layer — appended straight to `document.documentElement`
  instead of inside the popup, so it isn't clipped by the popup's
  rounded corners — that flares themed particles (ripples, drips,
  blades, glow, sparks) out past the popup's edge. `render.js` creates
  these layers when a popup opens, keeps the outer one synced to the
  popup's position on drag/resize/reopen, and tears both down on close.

## Privacy

The only network destination anywhere in this extension is
`https://jisho.org`; the words/substrings being looked up are sent
there because that's what looking up a word requires, and nowhere
else. There's no analytics, telemetry, tracking pixel, or third-party
SDK. Text-to-speech uses the browser's built-in `speechSynthesis`, not
a network call. The clipboard poll only reads text and only acts on it
if it contains Japanese characters — anything else you copy is read by
the poll like any text would be, but discarded immediately and never
sent anywhere. Nothing is logged or stored beyond the small local
caches described below. Source is all in this repo.

## Limitations

- **Not a real morphological analyzer.** The segmenter has no grammar
  model — it only recognizes strings that are themselves headwords in
  Jisho, so it won't correctly split inflected verb/adjective forms it
  doesn't recognize as their own entry. A real analyzer (kuromoji/MeCab)
  needs a multi-MB dictionary bundle and is out of scope here.
- "Combined meaning" only appears when the exact copied string is
  itself a Jisho headword, never a guessed or composed translation.
- No kanji radical/stroke/on-kun breakdown (the Rikaichan-style kanji
  card). Jisho's public API only covers word search, not kanji detail;
  that would need a separate kanjidic2 dataset.
- Furigana is the word's overall reading, not per-character aligned —
  true character alignment needs kanji-reading data this extension
  doesn't have.
- Romaji is a simplified Hepburn approximation: long vowels repeat the
  vowel letter instead of using a macron, and the sokuon (っ/ッ)
  doubling is exact except for the ち/チ row. See the comment in
  `lib/romaji.js`.
- Clipboard polling runs every 700ms while the extension is enabled
  (via a hidden offscreen document), not instant, and stops entirely
  when disabled from the toolbar icon.
- Dictionary cache is in-memory for the current service-worker
  instance, backed by `chrome.storage.session` so it survives
  service-worker restarts for the rest of the browser session (cleared
  when the browser closes). Only affects repeat-lookup speed, not
  correctness.
- Icons are placeholder (generated solid-color squares), not designed art.
- The scrollbar-themed effects (`content/effects.js`) haven't been
  checked in an actual browser. Layer creation, positioning math, spawn
  throttling, and the wiring into `render.js` are covered by `npm test`
  (see Tests below), but particle sizes, speeds, colors, and how they
  look against real page content are a first guess.
- Copied text over 120 characters is rejected with a message asking for
  a shorter selection, rather than segmenting a huge paste.

## Tests

```
npm test
```

runs four files, in order:

- `tests/segmenter.test.js` / `tests/romaji.test.js` — `lib/segmenter.js`
  and `lib/romaji.js` are pure functions (the segmenter takes an
  injectable lookup function so it can be tested without a network
  dependency). Covers longest-match precedence, punctuation/whitespace
  handling, and the romaji conversion rules (sokuon, long vowels,
  ん-apostrophe, yoon combos).
- `tests/effects.test.js` — `content/effects.js` in isolation: layer
  creation/teardown, `syncOuter`'s position math, per-theme particle
  spawning, the spawn throttle, and the inner-glow hold timer.
- `tests/integration.test.js` — `content/effects.js` and
  `content/render.js` loaded together, exercised through the popup
  lifecycle (`startPopup` → drag → window resize → close), the same
  way they run on a real page.

The last two use `tests/_fakeDom.js`, a small hand-rolled DOM/
`chrome.storage` shim run via Node's `vm` module — no jsdom dependency,
no `npm install` step.

`lib/dictionary.js` (the actual fetch call) isn't covered; that would
need a live network call or a fetch mock, and correctness there is
really about whether Jisho's API behaves as documented, not logic this
codebase owns.

## License

MIT — see [LICENSE](LICENSE).
