// Runs inside the hidden offscreen document created by background.js.
//
// MV3 service workers have no DOM, so navigator.clipboard and
// document.execCommand aren't available in background.js directly.
// navigator.clipboard.readText() also requires document focus, which
// an offscreen document never has, so this uses the older
// document.execCommand('paste'), which the "clipboardRead" permission
// unlocks without a user gesture.
//
// Polls on a timer instead of reacting to a copy event, which is the
// point: it catches text placed on the system clipboard by anything —
// an OS-level OCR tool, another app, a site that blocks selection —
// not just text selected on the page.

const POLL_MS = 700;
const target = document.getElementById('paste-target');

// Only used to skip re-sending an unchanged clipboard value on the
// next tick. Doesn't expire on a timer: an untouched clipboard would
// otherwise re-trigger the popup every few seconds.
let lastSeen = null;

function readClipboardOnce() {
  target.value = '';
  target.focus();
  const pasted = document.execCommand('paste');
  return pasted ? target.value : '';
}

function poll() {
  let text = '';
  try {
    text = readClipboardOnce();
  } catch {
    return; // unreadable this tick (non-text data, dismissed prompt); retry next tick
  }

  if (!text || text === lastSeen) return;
  lastSeen = text;

  chrome.runtime.sendMessage({ type: 'CLIPBOARD_TEXT', text }).catch(() => {
    // Background may be asleep between polls; the next tick retries.
  });
}

setInterval(poll, POLL_MS);
poll();
