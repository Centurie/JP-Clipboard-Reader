// Runs content/effects.js and content/render.js together, in the same
// sandbox they share on a real page, and drives them through the
// popup lifecycle: open, drag (resyncs the outer flare), browser
// resize (resyncs the outer flare), and close (tears both layers
// down).
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createFakeDom, loadScript } from './_fakeDom.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EFFECTS_PATH = path.join(__dirname, '../content/effects.js');
const RENDER_PATH = path.join(__dirname, '../content/render.js');
const POPUP_ID = '__jpcr_popup';

function outerLayers(documentElementEl) {
  return documentElementEl.children.filter((c) => c.className === '__jpcr_fx_outer');
}

async function run() {
  const { sandbox, document, documentElementEl, store } = createFakeDom();
  // Same load order as manifest.json's content_scripts: effects.js
  // before render.js, both sharing one execution context.
  loadScript(sandbox, EFFECTS_PATH);
  loadScript(sandbox, RENDER_PATH);
  assert.ok(sandbox.window.__jpcr, 'render.js should expose window.__jpcr');

  // 1. startPopup() wires the two together for real: it should call
  // effects.createLayers (not just something render.js could call), and
  // positionRoot should call syncOuter so the flare lands in the right
  // place on first open, not just get created at (0,0).
  store.scrollbarTheme = 'water';
  await sandbox.window.__jpcr.startPopup();

  const root = document.getElementById(POPUP_ID);
  assert.ok(root, 'startPopup should create and attach the popup root');
  assert.equal(outerLayers(documentElementEl).length, 1, 'startPopup should create exactly one outer fx layer');
  const outer = outerLayers(documentElementEl)[0];
  // root._rect defaults to all-zero; syncOuter's math off that rect proves
  // it actually ran as part of startPopup/positionRoot.
  assert.equal(outer.style.left, '-10px');
  assert.equal(outer.style.top, '-10px');
  assert.equal(outer.style.width, '36px');
  assert.equal(outer.style.height, '20px');

  const body = root.querySelector('.__jpcr_body');
  assert.ok(body, 'popup body should exist so effects.attach() had something to bind scroll to');
  assert.equal(root.dataset.scrollbar, 'water', 'saved scrollbar pref should reach the popup effects.js reads from');

  // A scroll on the real popup body (not a fake div) should spawn the
  // themed particle, proving attach() was wired to the real body element.
  body.scrollTop = 0; body.scrollHeight = 100; body.clientHeight = 50;
  body.dispatch('scroll');
  assert.equal(outer.children.length, 1);
  assert.equal(outer.children[0].className, '__jpcr_fx_ripple');

  // 2. Dragging the popup should resync the outer layer's position live,
  // not just on reopen.
  const dragbar = root.children[0];
  root._rect = { left: 100, top: 50, right: 420, bottom: 250, width: 320, height: 200 };
  dragbar.dispatch('pointerdown', { target: dragbar, clientX: 10, clientY: 10, pointerId: 1 });

  // Simulate the browser having relaid-out root at its new dragged
  // position by the time the move handler reads getBoundingClientRect().
  root._rect = { left: 130, top: 90, right: 450, bottom: 290, width: 320, height: 200 };
  dragbar.dispatch('pointermove', { clientX: 40, clientY: 50 });
  assert.equal(outer.style.left, '440px'); // 450 - 10
  assert.equal(outer.style.top, '80px'); // 90 - 10

  dragbar.dispatch('pointerup', { pointerId: 1 });
  // Individual field checks, not assert.deepEqual: popupPosition was
  // created inside the vm sandbox (a different realm), so its
  // Object.prototype differs from this file's and deepStrictEqual
  // would fail on that alone, not on the actual x/y values.
  assert.equal(store.popupPosition.x, 130, 'drag release should persist the new x');
  assert.equal(store.popupPosition.y, 90, 'drag release should persist the new y');

  // 3. Resizing the browser window should also resync the outer layer,
  // without a drag or reopen in between.
  root._rect = { left: 200, top: 20, right: 520, bottom: 220, width: 320, height: 200 };
  sandbox.window.dispatch('resize');
  assert.equal(outer.style.left, '510px'); // 520 - 10
  assert.equal(outer.style.top, '10px'); // 20 - 10

  // 4. Closing the popup should tear down BOTH fx layers via the real
  // close button, not leave the outer layer orphaned on <html>.
  const closeBtn = dragbar.children[dragbar.children.length - 1];
  closeBtn.dispatch('click');
  assert.equal(document.getElementById(POPUP_ID), null, 'close should remove the popup root');
  assert.equal(outerLayers(documentElementEl).length, 0, 'close should remove the outer fx layer too');

  // 5. After close, a resize with no popup open must not throw (no
  // stale root/currentFx reference left behind).
  assert.doesNotThrow(() => sandbox.window.dispatch('resize'));

  console.log('integration: all tests passed');
}

run();
