import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createFakeDom, loadScript } from './_fakeDom.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const EFFECTS_PATH = path.join(__dirname, '../content/effects.js');

function run() {
  const { sandbox, document, documentElementEl, perf, runTimers } = createFakeDom();
  loadScript(sandbox, EFFECTS_PATH);
  const fx = sandbox.window.__jpcr_effects;
  assert.ok(fx, 'effects.js should expose window.__jpcr_effects');

  // createLayers: inner and core both go inside root; outer goes on
  // document.documentElement (a sibling of root, NOT inside it — that's
  // what lets particles flare out past the popup's clipped, rounded-
  // corner edge). destroyLayers cleans up all three.
  {
    const root = document.createElement('div');
    const layers = fx.createLayers(root);
    assert.equal(root.children.includes(layers.inner), true);
    assert.equal(layers.inner.className, '__jpcr_fx_inner');
    assert.equal(root.children.includes(layers.core), true);
    assert.equal(layers.core.className, '__jpcr_fx_core');
    assert.equal(documentElementEl.children.includes(layers.outer), true);
    assert.equal(root.children.includes(layers.outer), false);
    assert.equal(layers.outer.className, '__jpcr_fx_outer');

    fx.destroyLayers(layers);
    assert.equal(documentElementEl.children.includes(layers.outer), false);
    assert.equal(root.children.includes(layers.inner), false);
    assert.equal(root.children.includes(layers.core), false);
  }

  // syncOuter: positions the outer layer from root's rect, extending
  // FLARE_OUT (26px) past the popup's right edge.
  {
    const root = document.createElement('div');
    root._rect = { left: 100, top: 50, right: 420, bottom: 250, width: 320, height: 200 };
    const layers = fx.createLayers(root);
    fx.syncOuter(root, layers);
    assert.equal(layers.outer.style.left, '410px'); // right - 10
    assert.equal(layers.outer.style.top, '40px'); // top - 10
    assert.equal(layers.outer.style.width, '36px'); // 10 + 26
    assert.equal(layers.outer.style.height, '220px'); // height + 20
  }

  // attach(): every scroll tick pulses the inner glow, even for the
  // "default" theme, which spawns no particles at all.
  {
    const root = document.createElement('div');
    root.dataset.scrollbar = 'default';
    const body = document.createElement('div');
    const layers = fx.createLayers(root);
    layers.outer._rect = { height: 200 };
    fx.attach(root, body, layers);

    body.dispatch('scroll');
    assert.equal(layers.inner.classList.contains('__jpcr_fx_inner_active'), true);
    assert.equal(layers.outer.children.length, 0);
  }

  // attach(): a themed scrollbar spawns the matching particle class,
  // positioned along the strip by scroll progress.
  {
    const root = document.createElement('div');
    root.dataset.scrollbar = 'water';
    const body = document.createElement('div');
    body.scrollTop = 50;
    body.scrollHeight = 200;
    body.clientHeight = 100; // max scroll 100 -> progress 0.5
    const layers = fx.createLayers(root);
    layers.outer._rect = { height: 200 };
    fx.attach(root, body, layers);

    body.dispatch('scroll');
    assert.equal(layers.outer.children.length, 1);
    assert.equal(layers.outer.children[0].className, '__jpcr_fx_ripple');
    assert.equal(layers.outer.children[0].style.top, '100px'); // 0.5 * 200
  }

  // attach(): spawn throttling (SPAWN_INTERVAL_MS = 90) blocks a second
  // particle until enough time has passed.
  {
    const root = document.createElement('div');
    root.dataset.scrollbar = 'blood';
    const body = document.createElement('div');
    body.scrollTop = 10; body.scrollHeight = 100; body.clientHeight = 50;
    const layers = fx.createLayers(root);
    layers.outer._rect = { height: 100 };
    fx.attach(root, body, layers);

    perf._now = 2000;
    body.dispatch('scroll');
    assert.equal(layers.outer.children.length, 1);

    perf._now = 2000 + 10; // well under the 90ms throttle
    body.dispatch('scroll');
    assert.equal(layers.outer.children.length, 1, 'throttled: no second particle yet');

    perf._now = 2000 + 100; // past the throttle window
    body.dispatch('scroll');
    assert.equal(layers.outer.children.length, 2, 'spawns again once interval has passed');
  }

  // Particles remove themselves once their lifetime timer fires.
  {
    const root = document.createElement('div');
    root.dataset.scrollbar = 'forest';
    const body = document.createElement('div');
    body.scrollTop = 0; body.scrollHeight = 100; body.clientHeight = 50;
    const layers = fx.createLayers(root);
    layers.outer._rect = { height: 100 };
    fx.attach(root, body, layers);

    perf._now = 5000;
    body.dispatch('scroll');
    assert.equal(layers.outer.children.length, 1);
    assert.equal(layers.outer.children[0].className, '__jpcr_fx_blade');
    runTimers();
    assert.equal(layers.outer.children.length, 0, 'particle removes itself after its lifetime');
  }

  // The inner glow lingers after scrolling stops rather than snapping off
  // instantly (INNER_GLOW_HOLD_MS = 350), and only clears once that timer
  // actually fires.
  {
    const root = document.createElement('div');
    root.dataset.scrollbar = 'sunset';
    const body = document.createElement('div');
    body.scrollTop = 0; body.scrollHeight = 100; body.clientHeight = 50;
    const layers = fx.createLayers(root);
    layers.outer._rect = { height: 100 };
    fx.attach(root, body, layers);

    perf._now = 9000;
    body.dispatch('scroll');
    assert.equal(layers.inner.classList.contains('__jpcr_fx_inner_active'), true);
    runTimers();
    assert.equal(layers.inner.classList.contains('__jpcr_fx_inner_active'), false);
  }

  console.log('effects: all tests passed');
}

run();
