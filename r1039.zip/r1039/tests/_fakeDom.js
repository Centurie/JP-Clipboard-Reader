// Minimal fake DOM + vm sandbox, just enough surface for effects.js and
// render.js to run unmodified under `node --test`-free plain scripts.
// No jsdom dependency (would need a network install this repo doesn't
// have) — this hand-rolls only what those two files actually touch:
// createElement/appendChild/remove, classList, dataset, style
// (incl. setProperty), addEventListener/dispatch, getBoundingClientRect,
// getElementById, a tag-only closest(), and pointer capture as no-ops.
import vm from 'node:vm';
import fs from 'node:fs';

function makeClassList() {
  const set = new Set();
  return {
    add: (c) => set.add(c),
    remove: (c) => set.delete(c),
    contains: (c) => set.has(c),
    toggle(c, force) {
      const want = force === undefined ? !set.has(c) : force;
      want ? set.add(c) : set.delete(c);
      return want;
    },
  };
}

function makeElement(tag, doc) {
  const listeners = {};
  const el = {
    tagName: String(tag).toUpperCase(),
    _doc: doc,
    _className: '',
    children: [],
    parentNode: null,
    style: {},
    dataset: {},
    _rect: { left: 0, top: 0, right: 0, bottom: 0, width: 0, height: 0 },
    get id() { return this._id || ''; },
    set id(v) { this._id = v; },
    get className() { return this._className; },
    set className(v) { this._className = v; this.classList = makeClassList(); },
    appendChild(child) {
      child.parentNode = this;
      this.children.push(child);
      return child;
    },
    insertBefore(child, ref) {
      child.parentNode = this;
      const i = ref ? this.children.indexOf(ref) : -1;
      if (i === -1) this.children.push(child); else this.children.splice(i, 0, child);
      return child;
    },
    remove() {
      if (this.parentNode) {
        const i = this.parentNode.children.indexOf(this);
        if (i >= 0) this.parentNode.children.splice(i, 1);
        this.parentNode = null;
      }
    },
    querySelector(sel) {
      const cls = sel.replace(/^\./, '');
      const walk = (node) => {
        for (const c of node.children) {
          if (c.className && c.className.split(' ').includes(cls)) return c;
          const found = walk(c);
          if (found) return found;
        }
        return null;
      };
      return walk(this);
    },
    closest(sel) {
      let node = this;
      while (node) {
        if (node.tagName === String(sel).toUpperCase()) return node;
        node = node.parentNode;
      }
      return null;
    },
    addEventListener(type, fn) { (listeners[type] = listeners[type] || []).push(fn); },
    removeEventListener(type, fn) {
      if (listeners[type]) listeners[type] = listeners[type].filter((f) => f !== fn);
    },
    dispatch(type, evt = {}) { for (const fn of (listeners[type] || []).slice()) fn(evt); },
    getBoundingClientRect() { return this._rect; },
    setPointerCapture() {},
    releasePointerCapture() {},
    setAttribute() {},
    offsetWidth: 320,
    offsetHeight: 200,
  };
  el.className = '';
  el.style.setProperty = (name, value) => { el.style[name] = value; };
  return el;
}

export function createFakeDom() {
  const documentElementEl = makeElement('html');

  const document = {
    documentElement: documentElementEl,
    createElement(tag) { return makeElement(tag); },
    getElementById(id) {
      // Walk the tree instead of trusting a stale byId map, since
      // elements can be removed independently of this lookup.
      const walk = (node) => {
        if (node._id === id) return node;
        for (const c of node.children) {
          const found = walk(c);
          if (found) return found;
        }
        return null;
      };
      return walk(documentElementEl);
    },
  };

  const store = {};
  const chrome = {
    storage: {
      local: {
        async get(keys) {
          const list = Array.isArray(keys) ? keys : [keys];
          const out = {};
          for (const k of list) if (k in store) out[k] = store[k];
          return out;
        },
        async set(obj) { Object.assign(store, obj); },
      },
    },
  };

  const timers = [];
  const fakeSetTimeout = (fn, ms) => { const h = { fn, ms }; timers.push(h); return h; };
  const fakeClearTimeout = (h) => { const i = timers.indexOf(h); if (i >= 0) timers.splice(i, 1); };
  const runTimers = () => { while (timers.length) timers.shift().fn(); };

  const perf = { _now: 1000, now() { return this._now; } };

  const sandbox = {
    document,
    chrome,
    performance: perf,
    setTimeout: fakeSetTimeout,
    clearTimeout: fakeClearTimeout,
    navigator: { clipboard: null },
    speechSynthesis: { speak() {} },
    SpeechSynthesisUtterance: function (t) { this.text = t; },
    console,
    Math,
    Set,
    Map,
    Number,
    JSON,
    Promise,
    Array,
    Object,
    String,
  };
  // window needs its own addEventListener/dispatch (render.js listens for
  // 'resize' at the top level) — separate from the element pub-sub above
  // since window isn't a fake element.
  const windowListeners = {};
  sandbox.window = sandbox;
  sandbox.window.innerWidth = 1280;
  sandbox.window.innerHeight = 800;
  sandbox.window.addEventListener = (type, fn) => {
    (windowListeners[type] = windowListeners[type] || []).push(fn);
  };
  sandbox.window.removeEventListener = (type, fn) => {
    if (windowListeners[type]) windowListeners[type] = windowListeners[type].filter((f) => f !== fn);
  };
  sandbox.window.dispatch = (type, evt = {}) => {
    for (const fn of (windowListeners[type] || []).slice()) fn(evt);
  };
  vm.createContext(sandbox);

  return { sandbox, document, chrome, store, timers, runTimers, perf, documentElementEl };
}

export function loadScript(sandbox, filePath) {
  const code = fs.readFileSync(filePath, 'utf8');
  vm.runInContext(code, sandbox, { filename: filePath });
}
