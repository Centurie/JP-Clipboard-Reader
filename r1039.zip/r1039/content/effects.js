// Themed visual effects tied to the scrollbar color (see popup.css for
// the swatch/gradient definitions). Two layers per popup:
//   - "inner": lives inside the popup root (clipped by its rounded
//     corners / overflow:hidden) — a soft glow along the inner edge of
//     the scrollbar gutter.
//   - "outer": a sibling of the popup root, appended straight to
//     document.documentElement so it isn't clipped by the popup's
//     overflow:hidden — this is what lets particles flare out past
//     the popup's edge.
// Exposed on window for the same reason render.js is: content scripts
// listed in manifest.json share one execution context, not ES modules.
(function () {
  const FLARE_OUT = 26; // px the outer layer extends past the popup's right edge
  const SPAWN_INTERVAL_MS = 90; // min gap between spawned particles
  const INNER_GLOW_HOLD_MS = 350; // how long the inner glow lingers after scrolling stops

  function createLayers(root) {
    const inner = document.createElement('div');
    inner.className = '__jpcr_fx_inner';
    root.appendChild(inner);

    // Always-visible spinning circle at the scrollbar's vertical
    // center — see popup.css for why this is a separate real element
    // rather than something drawn on the scrollbar thumb itself.
    const core = document.createElement('div');
    core.className = '__jpcr_fx_core';
    root.appendChild(core);

    const outer = document.createElement('div');
    outer.className = '__jpcr_fx_outer';
    document.documentElement.appendChild(outer);

    return { inner, core, outer };
  }

  function syncOuter(root, layers) {
    const rect = root.getBoundingClientRect();
    layers.outer.style.left = `${rect.right - 10}px`;
    layers.outer.style.top = `${rect.top - 10}px`;
    layers.outer.style.width = `${10 + FLARE_OUT}px`;
    layers.outer.style.height = `${rect.height + 20}px`;
  }

  function destroyLayers(layers) {
    layers.resizeObserver?.disconnect();
    layers.outer.remove();
    layers.inner.remove(); // dies with root anyway; removed defensively
    layers.core.remove();
  }

  function spawn(outer, el, lifetimeMs) {
    outer.appendChild(el);
    setTimeout(() => el.remove(), lifetimeMs);
  }

  function jitter(spread) {
    return (Math.random() * spread - spread / 2).toFixed(1);
  }

  // One spawn function per theme. `topPx` is where along the strip
  // (scroll-progress-based) the particle originates.

  function fxWater(outer, topPx) {
    const el = document.createElement('div');
    el.className = '__jpcr_fx_ripple';
    el.style.top = `${topPx}px`;
    spawn(outer, el, 700);
  }

  function fxBlood(outer, topPx) {
    const el = document.createElement('div');
    el.className = '__jpcr_fx_drip';
    el.style.top = `${topPx}px`;
    spawn(outer, el, 900);
  }

  function fxForest(outer, topPx) {
    const el = document.createElement('div');
    el.className = '__jpcr_fx_blade';
    el.style.top = `${topPx}px`;
    el.style.setProperty('--jitter', `${jitter(10)}px`);
    spawn(outer, el, 1100);
  }

  function fxSunset(outer, topPx) {
    const el = document.createElement('div');
    el.className = '__jpcr_fx_glow';
    el.style.top = `${topPx}px`;
    spawn(outer, el, 900);
  }

  function fxViolet(outer, topPx) {
    const el = document.createElement('div');
    el.className = '__jpcr_fx_spark';
    el.style.top = `${topPx}px`;
    el.style.setProperty('--jitter', `${jitter(16)}px`);
    el.style.setProperty('--hue', `${260 + Math.random() * 40}deg`);
    spawn(outer, el, 800);
  }

  const THEME_FX = {
    water: fxWater,
    blood: fxBlood,
    forest: fxForest,
    sunset: fxSunset,
    violet: fxViolet,
    // "default" has no entry — plain thumb, no particles.
  };

  function attach(root, body, layers) {
    let lastSpawn = -Infinity; // avoids wrongly throttling the very first spawn
    let hideTimer = null;

    body.addEventListener(
      'scroll',
      () => {
        const theme = root.dataset.scrollbar || 'default';

        // Inner glow pulses on every scroll tick regardless of theme,
        // and lingers briefly after scrolling stops.
        layers.inner.classList.add('__jpcr_fx_inner_active');
        clearTimeout(hideTimer);
        hideTimer = setTimeout(() => {
          layers.inner.classList.remove('__jpcr_fx_inner_active');
        }, INNER_GLOW_HOLD_MS);

        const fn = THEME_FX[theme];
        if (!fn) return;

        const now = performance.now();
        if (now - lastSpawn < SPAWN_INTERVAL_MS) return;
        lastSpawn = now;

        const max = body.scrollHeight - body.clientHeight;
        const progress = max > 0 ? body.scrollTop / max : 0;
        const rect = layers.outer.getBoundingClientRect();
        fn(layers.outer, progress * rect.height);
      },
      { passive: true }
    );

    // The bug this fixes: the outer layer was previously only
    // repositioned on drag and on window resize. But the popup itself
    // keeps growing taller as word cards stream in AFTER it opens —
    // that's not a drag or a window resize, so the outer layer stayed
    // sized to the small "Looking up…" shell while the real scrollbar
    // went on to span a much taller popup. Result: particles clustered
    // near the top no matter where you'd actually scrolled to.
    // ResizeObserver catches every size change to `root`, for any
    // reason, and stays correct for the whole life of the popup.
    if (typeof ResizeObserver !== 'undefined') {
      const ro = new ResizeObserver(() => syncOuter(root, layers));
      ro.observe(root);
      layers.resizeObserver = ro;
    }
  }

  window.__jpcr_effects = { createLayers, syncOuter, destroyLayers, attach };
})();
