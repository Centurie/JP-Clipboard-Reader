(function () {
  const JAPANESE_RE = /[\u3040-\u30ff\u3400-\u9fff]/;

  // Real `copy` event over a DOM selection on this page — zero latency,
  // but doesn't catch OCR'd or externally-copied text. The clipboard
  // poll in offscreen.js/background.js covers that via the RENDER_*
  // messages below.
  document.addEventListener('copy', onCopy, true);

  async function onCopy() {
    const { enabled = true } = await chrome.storage.local.get('enabled');
    if (!enabled) return;

    const text = window.getSelection().toString().trim();
    if (!text || !JAPANESE_RE.test(text)) return;

    runStreamedLookup(text);
  }

  function runStreamedLookup(text) {
    const port = chrome.runtime.connect({ name: 'lookup' });
    port.onMessage.addListener((msg) => {
      if (msg.type === 'BEGIN') window.__jpcr.startPopup();
      else if (msg.type === 'SKIPPED') return; // duplicate of a lookup already in flight
      else if (msg.type === 'TOKEN') window.__jpcr.addToken(msg.token);
      else if (msg.type === 'COMBINED') window.__jpcr.setCombined(msg.combined);
      else if (msg.type === 'DONE') window.__jpcr.finish();
      else if (msg.type === 'ERROR') window.__jpcr.showError(msg.message);
    });
    port.postMessage({ type: 'START', text });
  }

  // Pushed unprompted by background.js when its offscreen document sees
  // new Japanese text on the system clipboard (OCR tools, other apps,
  // pages that block selection). Streamed the same way as the port above.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'RENDER_START') window.__jpcr.startPopup();
    else if (msg?.type === 'RENDER_TOKEN') window.__jpcr.addToken(msg.token);
    else if (msg?.type === 'RENDER_COMBINED') window.__jpcr.setCombined(msg.combined);
    else if (msg?.type === 'RENDER_DONE') window.__jpcr.finish();
    else if (msg?.type === 'RENDER_ERROR') window.__jpcr.showError(msg.message);
  });
})();
