import { lookupExact } from './lib/dictionary.js';
import { segment } from './lib/segmenter.js';
import { toRomaji } from './lib/romaji.js';

const JAPANESE_RE = /[\u3040-\u30ff\u3400-\u9fff]/;
const MAX_TEXT_LEN = 120; // sane cap so an accidental huge paste doesn't hang the segmenter
const OFFSCREEN_URL = 'offscreen.html';
const DEDUPE_WINDOW_MS = 1500;

chrome.runtime.onInstalled.addListener(async () => {
  const { enabled } = await chrome.storage.local.get('enabled');
  if (enabled === undefined) await chrome.storage.local.set({ enabled: true });
  await refreshBadge();
  await syncOffscreenDocument();
});

chrome.runtime.onStartup.addListener(async () => {
  await syncOffscreenDocument();
});

chrome.action.onClicked.addListener(async () => {
  const { enabled = true } = await chrome.storage.local.get('enabled');
  await chrome.storage.local.set({ enabled: !enabled });
  await refreshBadge();
  await syncOffscreenDocument();
});

async function refreshBadge() {
  const { enabled = true } = await chrome.storage.local.get('enabled');
  await chrome.action.setBadgeText({ text: enabled ? 'ON' : 'OFF' });
  await chrome.action.setBadgeBackgroundColor({
    color: enabled ? '#4caf50' : '#888888',
  });
}

// Keeps exactly one offscreen document alive while the extension is
// enabled (it's what polls the system clipboard — see offscreen.js),
// and tears it down when disabled so nothing runs in the background
// for no reason.
async function syncOffscreenDocument() {
  const { enabled = true } = await chrome.storage.local.get('enabled');
  const has = await hasOffscreenDocument();

  if (enabled && !has) {
    await chrome.offscreen.createDocument({
      url: OFFSCREEN_URL,
      reasons: ['CLIPBOARD'],
      justification:
        'Poll the system clipboard for copied Japanese text so lookups work no matter what app or tool put the text there (not just text selected on the page).',
    });
  } else if (!enabled && has) {
    await chrome.offscreen.closeDocument();
  }
}

async function hasOffscreenDocument() {
  const contexts = await chrome.runtime.getContexts({
    contextTypes: ['OFFSCREEN_DOCUMENT'],
  });
  return contexts.length > 0;
}

// Guards against the two trigger paths (an in-page `copy` event AND the
// clipboard poll) both firing for the same physical copy and rendering
// the popup twice. Deliberately time-boxed rather than permanent — see
// the comment on `lastSeen` in offscreen.js for why permanent dedupe
// would be worse, not better.
let lastProcessed = { text: '', ts: 0 };
function shouldProcess(text) {
  const now = Date.now();
  if (text === lastProcessed.text && now - lastProcessed.ts < DEDUPE_WINDOW_MS) {
    return false;
  }
  lastProcessed = { text, ts: now };
  return true;
}

// Attaches a romanized reading to an entry without mutating the
// cached object (the same entry may be handed out to multiple callers).
function withRomaji(entry) {
  if (!entry) return entry;
  const reading = entry.japanese?.[0]?.reading || '';
  return { ...entry, _romaji: toRomaji(reading) };
}

// Shared by both trigger paths. Streams results via callbacks instead
// of returning one big object, so the popup can fill in word-by-word
// instead of showing a blank "looking up" state for the whole phrase.
async function runLookup(rawText, { onToken, onCombined, onDone, onError }) {
  try {
    const text = rawText.trim();
    if (!text) {
      onDone?.();
      return;
    }
    if (text.length > MAX_TEXT_LEN) {
      onError?.(`Copied text is long (${text.length} chars) — select a shorter phrase.`);
      return;
    }

    const combinedPromise = text.length > 1
      ? lookupExact(text).catch(() => null)
      : Promise.resolve(null);
    combinedPromise.then((entry) => {
      if (entry) onCombined?.(withRomaji(entry));
    });

    await segment(text, undefined, (token) => {
      onToken?.({ surface: token.surface, entry: withRomaji(token.entry) });
    });
    await combinedPromise;
    onDone?.();
  } catch (err) {
    onError?.(String(err));
  }
}

// Fast path: content.js caught a real `copy` event with a genuine DOM
// selection and streams the lookup over a long-lived port so the
// popup fills in as results arrive.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'lookup') return;

  port.onMessage.addListener((msg) => {
    if (msg?.type !== 'START') return;

    // Checked and acknowledged *before* touching the popup: if this
    // duplicates a lookup that just ran (both the in-page copy event
    // and the clipboard poll caught the same physical copy), the
    // content script must NOT tear down whatever's already showing.
    if (!shouldProcess(msg.text)) {
      port.postMessage({ type: 'SKIPPED' });
      return;
    }
    port.postMessage({ type: 'BEGIN' });

    runLookup(msg.text, {
      onToken: (token) => port.postMessage({ type: 'TOKEN', token }),
      onCombined: (combined) => port.postMessage({ type: 'COMBINED', combined }),
      onDone: () => port.postMessage({ type: 'DONE' }),
      onError: (message) => port.postMessage({ type: 'ERROR', message }),
    });
  });
});

// Poll path: offscreen.js noticed the OS clipboard changed. There's no
// requester waiting on a response here — push results to whichever tab
// the user is actually looking at, streamed the same way as the port.
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === 'CLIPBOARD_TEXT') {
    handleClipboardText(msg.text);
  }
  return false;
});

async function handleClipboardText(rawText) {
  const text = (rawText || '').trim();
  if (!text || !JAPANESE_RE.test(text)) return;

  const { enabled = true } = await chrome.storage.local.get('enabled');
  if (!enabled) return;
  if (!shouldProcess(text)) return;

  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) return;

  const send = (message) => chrome.tabs.sendMessage(tab.id, message).catch(() => {
    // No content script in this tab (chrome://, the Web Store, a PDF
    // viewer, etc.) — nothing sensible to do, so just drop it.
  });

  await send({ type: 'RENDER_START' });
  await runLookup(text, {
    onToken: (token) => send({ type: 'RENDER_TOKEN', token }),
    onCombined: (combined) => send({ type: 'RENDER_COMBINED', combined }),
    onDone: () => send({ type: 'RENDER_DONE' }),
    onError: (message) => send({ type: 'RENDER_ERROR', message }),
  });
}
