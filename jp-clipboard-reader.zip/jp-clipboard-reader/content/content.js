(function () {
  const JAPANESE_RE = /[\u3040-\u30ff\u3400-\u9fff]/;

  // Instant path: fires only when the browser's real `copy` event fires
  // over a genuine DOM selection on THIS page. Kept because it's
  // zero-latency when it applies. It does not catch text that was
  // OCR'd from an image, copied from another app, or copied on a page
  // that blocks selection — background.js's clipboard poll (see
  // offscreen.js) covers those cases instead, via the RENDER_* messages
  // handled below.
  document.addEventListener('copy', onCopy, true);

  async function onCopy() {
    const { enabled = true } = await chrome.storage.local.get('enabled');
    if (!enabled) return;

    const text = window.getSelection().toString().trim();
    if (!text || !JAPANESE_RE.test(text)) return;

    runStreamedLookup(text);
  }

  function runStreamedLookup(text) {
    const port = chrome.runtime.connect({ name: 'lookup' });
    port.onMessage.addListener((msg) => {
      // BEGIN only arrives once background confirms this isn't a
      // duplicate of a lookup already in flight — only then is it
      // safe to tear down whatever popup is currently showing.
      if (msg.type === 'BEGIN') window.__jpcr.startPopup();
      else if (msg.type === 'SKIPPED') return; // leave the existing popup alone
      else if (msg.type === 'TOKEN') window.__jpcr.addToken(msg.token);
      else if (msg.type === 'COMBINED') window.__jpcr.setCombined(msg.combined);
      else if (msg.type === 'DONE') window.__jpcr.finish();
      else if (msg.type === 'ERROR') window.__jpcr.showError(msg.message);
    });
    port.postMessage({ type: 'START', text });
  }

  // Poll path: background.js pushes these unprompted whenever its
  // offscreen document notices the system clipboard changed to new
  // Japanese text — this is what makes copies from outside the page
  // (an OCR overlay reading a manga panel, another app, a site that
  // blocks text selection) work at all. Streamed the same way as the
  // direct path above, just over runtime messages instead of a port.
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'RENDER_START') window.__jpcr.startPopup();
    else if (msg?.type === 'RENDER_TOKEN') window.__jpcr.addToken(msg.token);
    else if (msg?.type === 'RENDER_COMBINED') window.__jpcr.setCombined(msg.combined);
    else if (msg?.type === 'RENDER_DONE') window.__jpcr.finish();
    else if (msg?.type === 'RENDER_ERROR') window.__jpcr.showError(msg.message);
  });
})();
