// Renders the popup panel. Exposed on window because content scripts
// in the manifest's "js" array share one execution context but not
// ES module scope — this keeps content.js free of import/CSP issues.
(function () {
  const POPUP_ID = '__jpcr_popup';
  const DEFAULT_WIDTH = 320; // matches popup.css max-width — used only for initial placement math
  const DEFAULT_HEIGHT = 200; // rough starting guess; the popup grows downward from here, it doesn't recenter as content streams in

  function createRoot() {
    removeRoot();
    const root = document.createElement('div');
    root.id = POPUP_ID;
    root.style.visibility = 'hidden'; // revealed once positioned, so it never flashes at (0,0)
    document.documentElement.appendChild(root);
    return root;
  }

  function removeRoot() {
    const existing = document.getElementById(POPUP_ID);
    if (existing) existing.remove();
  }

  function getBody() {
    const root = document.getElementById(POPUP_ID);
    return root ? root.querySelector('.__jpcr_body') : null;
  }

  function clamp(v, min, max) {
    return Math.min(Math.max(v, min), max);
  }

  async function applyTheme(root) {
    let theme = 'light';
    try {
      ({ theme = 'light' } = await chrome.storage.local.get('theme'));
    } catch (err) {
      // storage read failed (e.g. extension context invalidated) — fall
      // back to the default theme instead of throwing and skipping the
      // rest of startPopup(), which would leave the popup stuck at
      // visibility:hidden forever.
    }
    root.dataset.theme = theme;
  }

  function toggleTheme(root, btn) {
    const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
    root.dataset.theme = next;
    btn.textContent = next === 'dark' ? '\u263e' : '\u2600';
    chrome.storage.local.set({ theme: next });
  }

  // No cursor-position placement anymore (per feedback: it doesn't need
  // to open at the cursor). Opens at wherever it was last dragged to,
  // or centered in the viewport the first time.
  async function positionRoot(root) {
    let popupPosition;
    try {
      ({ popupPosition } = await chrome.storage.local.get('popupPosition'));
    } catch (err) {
      // storage read failed — fall back to centering instead of leaving
      // the popup stuck at visibility:hidden forever.
      popupPosition = null;
    }
    let x;
    let y;

    if (popupPosition && Number.isFinite(popupPosition.x) && Number.isFinite(popupPosition.y)) {
      x = clamp(popupPosition.x, 0, Math.max(0, window.innerWidth - DEFAULT_WIDTH));
      y = clamp(popupPosition.y, 0, Math.max(0, window.innerHeight - DEFAULT_HEIGHT));
    } else {
      x = Math.max(0, (window.innerWidth - DEFAULT_WIDTH) / 2);
      y = Math.max(0, (window.innerHeight - DEFAULT_HEIGHT) / 2);
    }

    root.style.left = `${x}px`;
    root.style.top = `${y}px`;
    root.style.visibility = 'visible';
  }

  // Drag by the top bar only, so grabbing a word/definition to select
  // text inside the popup doesn't fight with moving it. Position is
  // saved on release so next time it opens back where it was left.
  function enableDrag(root, handle) {
    let dragging = false;
    let startX = 0;
    let startY = 0;
    let originX = 0;
    let originY = 0;

    handle.addEventListener('pointerdown', (e) => {
      if (e.target.closest('button')) return;
      dragging = true;
      startX = e.clientX;
      startY = e.clientY;
      const rect = root.getBoundingClientRect();
      originX = rect.left;
      originY = rect.top;
      handle.setPointerCapture(e.pointerId);
    });

    handle.addEventListener('pointermove', (e) => {
      if (!dragging) return;
      const x = clamp(originX + (e.clientX - startX), 0, window.innerWidth - root.offsetWidth);
      const y = clamp(originY + (e.clientY - startY), 0, window.innerHeight - root.offsetHeight);
      root.style.left = `${x}px`;
      root.style.top = `${y}px`;
    });

    const endDrag = (e) => {
      if (!dragging) return;
      dragging = false;
      handle.releasePointerCapture(e.pointerId);
      const rect = root.getBoundingClientRect();
      chrome.storage.local.set({ popupPosition: { x: rect.left, y: rect.top } });
    };
    handle.addEventListener('pointerup', endDrag);
    handle.addEventListener('pointercancel', endDrag);
  }

  // Called once per NEW lookup (never for a duplicate — see content.js).
  // Tears down any existing popup, so copying new text while one is
  // still open replaces it automatically; only the close button
  // dismisses it otherwise (no more click-outside-to-close, which is
  // what made it impossible to drag).
  async function startPopup() {
    const root = createRoot();

    const dragbar = document.createElement('div');
    dragbar.className = '__jpcr_dragbar';

    const close = document.createElement('button');
    close.className = '__jpcr_close';
    close.type = 'button';
    close.textContent = '\u00d7';
    close.title = 'Close';
    close.addEventListener('click', removeRoot);
    dragbar.appendChild(close);

    root.appendChild(dragbar);
    enableDrag(root, dragbar);

    // Body is created and attached synchronously, before any await below.
    // startPopup() is fired-and-forgotten by content.js (never awaited),
    // so a TOKEN/RENDER_TOKEN message for a cache hit can arrive while
    // this function is still suspended on a storage read. Previously the
    // body didn't exist yet at that point, so addToken()'s `if (!body)
    // return;` guard silently dropped the token. Attaching it up front
    // closes that race window.
    const body = document.createElement('div');
    body.className = '__jpcr_body';
    const loading = document.createElement('div');
    loading.className = '__jpcr_card __jpcr_loading';
    loading.textContent = 'Looking up\u2026';
    body.appendChild(loading);
    root.appendChild(body);

    const themeBtn = document.createElement('button');
    themeBtn.className = '__jpcr_theme_toggle';
    themeBtn.type = 'button';
    themeBtn.title = 'Toggle dark mode';
    themeBtn.addEventListener('click', () => toggleTheme(root, themeBtn));
    root.appendChild(themeBtn);

    await applyTheme(root);
    themeBtn.textContent = root.dataset.theme === 'dark' ? '\u263e' : '\u2600';

    await positionRoot(root);
  }

  function clearLoading(body) {
    const loading = body.querySelector('.__jpcr_loading');
    if (loading) loading.remove();
  }

  // Streaming entry points — called as background.js resolves each
  // token instead of all at once, so words appear as they're found
  // rather than after the whole phrase finishes.
  function addToken(token) {
    const body = getBody();
    if (!body) return;
    clearLoading(body);

    if (token.entry) {
      body.appendChild(renderEntryCard(token.entry, { surface: token.surface }));
    } else {
      const unknown = document.createElement('div');
      unknown.className = '__jpcr_card __jpcr_unknown';
      unknown.textContent = `${token.surface} \u2014 no dictionary entry`;
      body.appendChild(unknown);
    }
  }

  function setCombined(entry) {
    const body = getBody();
    if (!body) return;
    clearLoading(body);
    body.insertBefore(renderEntryCard(entry, { combined: true }), body.firstChild);
  }

  function finish() {
    const body = getBody();
    if (!body) return;
    clearLoading(body);
    if (!body.firstChild) {
      const empty = document.createElement('div');
      empty.className = '__jpcr_card __jpcr_unknown';
      empty.textContent = 'No entries found.';
      body.appendChild(empty);
    }
  }

  function showError(message) {
    const body = getBody();
    if (!body) return;
    body.replaceChildren();
    const card = document.createElement('div');
    card.className = '__jpcr_card __jpcr_unknown';
    card.textContent = message;
    body.appendChild(card);
  }

  function renderEntryCard(entry, { combined = false, surface } = {}) {
    const card = document.createElement('div');
    card.className = '__jpcr_card' + (combined ? ' __jpcr_combined' : '');

    if (combined) {
      const label = document.createElement('div');
      label.className = '__jpcr_combined_label';
      label.textContent = 'Combined meaning';
      card.appendChild(label);
    }

    const jp = entry.japanese[0] || {};
    const word = surface || jp.word || jp.reading || '';
    const reading = jp.reading || '';

    if (reading && reading !== word) {
      const furigana = document.createElement('div');
      furigana.className = '__jpcr_furigana';
      furigana.textContent = reading;
      card.appendChild(furigana);
    }

    const head = document.createElement('div');
    head.className = '__jpcr_head';

    const wordEl = document.createElement('span');
    wordEl.className = '__jpcr_word';
    wordEl.textContent = word;
    head.appendChild(wordEl);

    const actions = document.createElement('span');
    actions.className = '__jpcr_actions';

    if (entry._romaji) {
      const romajiBox = document.createElement('span');
      romajiBox.className = '__jpcr_romaji';
      romajiBox.textContent = entry._romaji;
      actions.appendChild(romajiBox);
    }

    actions.appendChild(makeIconButton('\u29c9', 'Copy word', () => {
      navigator.clipboard?.writeText(word).catch(() => {});
    }));
    actions.appendChild(makeIconButton('\u25b6', 'Play pronunciation', () => {
      const utter = new SpeechSynthesisUtterance(reading || word);
      utter.lang = 'ja-JP';
      speechSynthesis.speak(utter);
    }));
    head.appendChild(actions);
    card.appendChild(head);

    // Map, not Set: dedups by tag text while remembering which color
    // category (part-of-speech / JLPT / common) each one belongs to.
    const tagSet = new Map();
    if (entry.is_common) tagSet.set('common', 'common');
    (entry.jlpt || []).forEach((l) => tagSet.set(l.replace('jlpt-', '').toUpperCase(), 'jlpt'));
    (entry.senses[0]?.parts_of_speech || []).forEach((p) => tagSet.set(p, 'pos'));

    if (tagSet.size > 0) {
      const tags = document.createElement('div');
      tags.className = '__jpcr_tags';
      for (const [text, kind] of tagSet) {
        const tag = document.createElement('span');
        tag.className = '__jpcr_tag';
        tag.dataset.kind = kind;
        tag.textContent = text;
        tags.appendChild(tag);
      }
      card.appendChild(tags);
    }

    const defs = document.createElement('ol');
    defs.className = '__jpcr_defs';
    const seen = new Set();
    for (const sense of entry.senses) {
      const text = sense.english_definitions.join('; ');
      const key = text.toLowerCase();
      if (seen.has(key)) continue; // Jisho occasionally repeats a sense differing only in casing
      seen.add(key);
      const li = document.createElement('li');
      li.textContent = text;
      defs.appendChild(li);
    }
    card.appendChild(defs);

    return card;
  }

  function makeIconButton(glyph, label, onClick) {
    const btn = document.createElement('button');
    btn.className = '__jpcr_icon_btn';
    btn.type = 'button';
    btn.title = label;
    btn.setAttribute('aria-label', label);
    btn.textContent = glyph;
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      onClick();
    });
    return btn;
  }

  window.__jpcr = {
    startPopup,
    addToken,
    setCombined,
    finish,
    showError,
    removePopup: removeRoot,
  };
})();
