import assert from 'node:assert/strict';
import { segment } from '../lib/segmenter.js';

// Fake dictionary so this test has no network dependency and doesn't
// depend on Jisho's live data. Only tests the segmentation algorithm
// itself (longest-match-first over a lookup function), not the
// real dictionary content or the live API call.
const FAKE = {
  '出来る': entry('出来る', 'できる', ['to be able to do'], ['Ichidan verb'], true, ['jlpt-n5']),
  '出来': entry('出来', 'でき', ['quality', 'result'], [], true, []),
  '猫': entry('猫', 'ねこ', ['cat'], ['Noun'], true, ['jlpt-n5']),
};

function entry(word, reading, defs, pos, common, jlpt) {
  return {
    japanese: [{ word, reading }],
    senses: [{ english_definitions: defs, parts_of_speech: pos }],
    is_common: common,
    jlpt,
  };
}

async function fakeLookup(word) {
  return FAKE[word] || null;
}

async function run() {
  // Longest match wins: "出来る" should not split into "出来" + "る".
  {
    const tokens = await segment('出来る', fakeLookup);
    assert.equal(tokens.length, 1);
    assert.equal(tokens[0].surface, '出来る');
    assert.equal(tokens[0].entry.japanese[0].reading, 'できる');
  }

  // Unknown character falls back to a single-char token with entry: null.
  {
    const tokens = await segment('猫出来る', fakeLookup);
    assert.equal(tokens.length, 2);
    assert.equal(tokens[0].surface, '猫');
    assert.equal(tokens[0].entry.japanese[0].word, '猫');
    assert.equal(tokens[1].surface, '出来る');
  }

  // Whitespace is skipped, not tokenized.
  {
    const tokens = await segment('猫 出来る', fakeLookup);
    assert.equal(tokens.length, 2);
  }

  // Fully unknown text: every char becomes its own null-entry token.
  {
    const tokens = await segment('未知', fakeLookup);
    assert.equal(tokens.length, 2);
    assert.equal(tokens[0].entry, null);
    assert.equal(tokens[1].entry, null);
  }

  console.log('segmenter: all tests passed');
}

run();
