import assert from 'node:assert/strict';
import { toRomaji } from '../lib/romaji.js';

function run() {
  assert.equal(toRomaji('できる'), 'dekiru');
  assert.equal(toRomaji('がっこう'), 'gakkou'); // sokuon doubles the following consonant
  assert.equal(toRomaji('きって'), 'kitte');
  assert.equal(toRomaji('コーヒー'), 'koohii'); // long vowel mark repeats the previous vowel
  assert.equal(toRomaji('きんえん'), "kin'en"); // ん before a vowel gets an apostrophe
  assert.equal(toRomaji('ほん'), 'hon'); // ん not before a vowel: no apostrophe
  assert.equal(toRomaji('きょう'), 'kyou'); // yoon (small y) combo
  assert.equal(toRomaji('ファイル'), 'fairu'); // extended katakana combo (ファ)
  assert.equal(toRomaji('出来る'), '出来ru'); // kanji passes through unchanged, only the kana part converts

  console.log('romaji: all tests passed');
}

run();
