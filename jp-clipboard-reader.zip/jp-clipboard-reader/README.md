# JP Clipboard Reader

Copy Japanese text — by selecting it on a page, or via an external OCR
tool that writes straight to the system clipboard — and a panel shows
per-word definitions, plus a combined-phrase definition when the whole
copied string is itself a dictionary entry. Data source: the public
Jisho.org API.

## Install in Opera

1. `opera://extensions`
2. Enable **Developer mode** (top right)
3. **Load unpacked** → select this folder
4. Click the toolbar icon once to confirm it shows **ON** (click again to disable)

Should also load as-is in any Chromium browser (`chrome://extensions`).

## Interface

- Light theme by default; the small circle bottom-right toggles dark mode
  (persisted).
- **Drag the top bar** to move the panel; it reopens at that position next
  time, until you drag it again. First-ever open is centered in the viewport.
- Only the **×** closes it. Clicking elsewhere on the page no longer closes
  it — that was what made dragging impossible before.
- Copying new text while a panel is open replaces it automatically — no
  need to close the old one first.
- Each word: reading above, kanji/kana headword, romanized reading, a copy
  icon, a pronunciation (TTS) icon, JLPT/part-of-speech/common tags, and
  numbered definitions.
- Definitions stream in as they're found rather than waiting for the whole
  phrase before showing anything.

## How it works

- `content/content.js` listens for the browser's native `copy` event
  (instant, but only catches real on-page selections).
- `offscreen.js` (an offscreen document, spun up by `background.js`) polls
  the actual OS clipboard every 700ms via `document.execCommand('paste')`,
  so it also catches text placed there by an external OCR tool, another
  app, or a site that blocks normal text selection.
- Both paths message `background.js`, which does the Jisho lookups
  (service workers aren't bound by the host page's CSP) and streams
  results back token-by-token as `lib/segmenter.js` resolves them.
- `lib/segmenter.js` splits the copied string into words via greedy
  longest-match against live Jisho lookups.
- `lib/romaji.js` renders a romanized reading locally — no extra network
  call.
- `content/render.js` builds and positions the panel.

## Privacy

The only network destination anywhere in this extension is
`https://jisho.org` — the words/substrings being looked up are sent there
because that's what "look up a word" requires, and nowhere else. There is
no analytics, telemetry, tracking pixel, or third-party SDK. Text-to-speech
uses the browser's built-in `speechSynthesis`, not a network call. The
clipboard poll only reads text and only acts on it if it contains Japanese
characters — non-Japanese clipboard content (passwords, card numbers,
anything else you copy day-to-day) is read by the poll like any text would
be, but is discarded immediately and never sent anywhere; nothing is
logged or stored beyond the small local caches described below. Source is
all in this folder — read any file to verify.

## Limitations (acknowledging what this does *not* do)

- **Not a real morphological analyzer.** The segmenter has no grammar
  model — it only recognizes strings that are themselves headwords in
  Jisho. It will not correctly split inflected verb/adjective forms it
  doesn't recognize as their own entry. A proper fix is a real analyzer
  (kuromoji/MeCab), which needs a multi-MB dictionary bundle — out of
  scope here.
- **"Combined meaning" only appears when the exact copied string is
  itself a Jisho headword** — never a guessed/composed translation.
- **No kanji radical/stroke/on-kun breakdown** (the Rikaichan-style kanji
  card). Jisho's public API only covers word search, not kanji detail;
  that would need a separate kanjidic2 dataset. Not implemented.
- **Furigana is the word's overall reading, not per-character aligned** —
  getting true character-by-character alignment needs kanji-reading data
  this extension doesn't have.
- **Romaji is a simplified Hepburn approximation** — long vowels repeat
  the vowel letter instead of using a macron, and the sokuon (っ/ッ)
  doubling is exact except for the ち/チ row. See the comment in
  `lib/romaji.js`.
- **Clipboard polling runs every 700ms** while the extension is enabled
  (via a hidden offscreen document) — a deliberate latency/overhead
  trade-off, not instant, and stops entirely when you disable the
  extension from the toolbar icon.
- **Dictionary cache**: an in-memory cache for the current service-worker
  instance, backed by `chrome.storage.session` so it survives service-worker
  restarts for the rest of the browser session (cleared when the browser
  closes). Only affects repeat-lookup speed, not correctness.
- **Icons are placeholder** (generated solid-color squares), not designed art.
- Copied text over 120 characters is rejected with a message asking for a
  shorter selection, rather than segmenting a huge paste.

## Tests

`lib/segmenter.js` and `lib/romaji.js` are both pure functions (the
segmenter takes an injectable lookup function specifically so it can be
tested without a network dependency):

```
npm test
```

covers longest-match precedence, punctuation/whitespace handling, and the
romaji conversion rules (sokuon, long vowels, ん-apostrophe, yoon combos).
`lib/dictionary.js` (the actual fetch call) isn't covered — it would need
a live network call or a fetch mock, and correctness there is really "does
Jisho's API behave as documented," not logic this codebase owns.
