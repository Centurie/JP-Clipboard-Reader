// Runs inside the hidden offscreen document created by background.js.
//
// Why this file exists at all: MV3 service workers have no DOM, so
// there is no navigator.clipboard / document.execCommand available in
// background.js directly. An offscreen document is Chrome's sanctioned
// place to get a real (if invisible) DOM for exactly this kind of thing.
// Even inside an offscreen document, navigator.clipboard.readText() is
// blocked (it requires document focus, which offscreen documents can
// never have) — so we fall back to the older document.execCommand('paste')
// API, which the "clipboardRead" permission unlocks without needing a
// user gesture.
//
// This polls on a timer rather than reacting to a browser copy event,
// which is the whole point: it catches text that was put on the system
// clipboard by *anything* — an OS-level OCR tool over a manga panel, a
// different app, a right-click "copy" on a site that blocks normal
// selection — not just text selected and copied from a real DOM node
// on the page.

const POLL_MS = 700;
const target = document.getElementById('paste-target');

// Only used to avoid re-sending the *same unchanged* clipboard value
// on every tick. It intentionally does not expire on a timer: if it
// did, an untouched clipboard would re-trigger the popup forever every
// few seconds, which would be far more annoying than occasionally
// needing to copy something else and back to reopen a word.
let lastSeen = null;

function readClipboardOnce() {
  target.value = '';
  target.focus();
  const pasted = document.execCommand('paste');
  return pasted ? target.value : '';
}

function poll() {
  let text = '';
  try {
    text = readClipboardOnce();
  } catch {
    // Clipboard unreadable this tick (e.g. it holds non-text data, or
    // a permission prompt got dismissed). Just retry next tick.
    return;
  }

  if (!text || text === lastSeen) return;
  lastSeen = text;

  chrome.runtime.sendMessage({ type: 'CLIPBOARD_TEXT', text }).catch(() => {
    // Background may be momentarily asleep between polls — harmless,
    // the next tick (or the next genuinely new copy) will retry.
  });
}

setInterval(poll, POLL_MS);
poll();
